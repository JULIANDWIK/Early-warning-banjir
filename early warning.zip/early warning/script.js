const ctx = document.getElementById('waterChart');


new Chart(ctx,{


type:'line',



data:{


labels:[

"17:00",
"17:05",
"17:10",
"17:15",
"17:20",
"17:25",
"17:30"

],



datasets:[{


label:"Ketinggian Air (cm)",



data:[

1,
2,
2.5,
3,
4.8,
6,
8.2

],



borderColor:"#38bdf8",


backgroundColor:"rgba(56,189,248,0.15)",



borderWidth:3,


pointRadius:5,


fill:true,


tension:0.4


}]


},




options:{


responsive:true,


maintainAspectRatio:false,



plugins:{


legend:{


labels:{


color:"white"


}


}


},




scales:{



x:{


ticks:{


color:"#94a3b8"


}


},




y:{


beginAtZero:true,


ticks:{


color:"#94a3b8"


}


}


}



}



});